
# Virtual-Assistant-using-Python
To start the project run "first_of_VA2.py".
This is virtual assistant which takes input as voice command using speech-recognition api and gives output as voice using pyttsx3 engine.
All the tasks are saved in Database and to add a certain task or query to database we can use "add" keyword so that the assistant remembers it.
Questions can be answered using wolframalpha api and wikipedia api.
"process_module.py" handles all the task related queries that needs to be performed by the VA.
"web_jobs.py" handles all the web related tasks using internet and webbrowser module of python.

//:)
